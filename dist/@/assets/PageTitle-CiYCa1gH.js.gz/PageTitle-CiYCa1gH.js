import{j as e}from"./index-CMwVzeIB.js";const a=({children:t})=>e.jsx("h1",{className:"my-6 text-lg font-bold text-gray-700 dark:text-gray-300",children:t});export{a as P};
