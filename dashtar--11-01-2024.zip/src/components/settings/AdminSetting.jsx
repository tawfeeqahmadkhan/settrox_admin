import React from "react";

const AdminSetting = () => {
  return (
    <div>
      <h2>Will Be added All static translation for admin</h2>
    </div>
  );
};

export default AdminSetting;
