const AnimatedContent = ({ children }) => {
  return <div className="tab tab-enter">{children}</div>;
};

export default AnimatedContent;
